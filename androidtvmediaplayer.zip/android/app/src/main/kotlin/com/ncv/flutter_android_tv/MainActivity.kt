package com.ncv.flutter_android_tv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
