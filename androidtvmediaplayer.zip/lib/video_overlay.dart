import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import 'key_code.dart';

class VideoIndicator extends StatefulWidget {
  final VideoPlayerController controller;
  const VideoIndicator(
      {Key? key,
      required this.controller,})
      : super(key: key);

  @override
  _VideoIndicatorState createState() => _VideoIndicatorState();
}

class _VideoIndicatorState extends State<VideoIndicator> {
  FocusNode playPauseFocusNode = FocusNode();
  FocusNode fastRewind = FocusNode();
  FocusNode fastForward = FocusNode();
  // var showVideoController = true;
  // late Timer _timer;
  //
  //
  // void _setControllerState(){
  //   setState(() {
  //     showVideoController = true;
  //   });
  //   if(_timer.isActive){
  //     clearTimeOut();
  //   }
  //   _timeOut();
  // }
  // void _timeOut({int seconds = 10}){
  //   _timer = Timer(Duration(seconds: seconds),(){
  //     if(this.mounted){
  //       setState(() {
  //         showVideoController = false;
  //       });
  //     }
  //   });
  // }
  // void clearTimeOut(){
  //   _timer.cancel();
  // }
  // @override
  // void dispose() {
  //   clearTimeOut();
  //   super.dispose();
  // }

  void _setKeyEvent(RawKeyEvent event) {
    // _setControllerState();
    if (event is RawKeyDownEvent &&
        event.data is RawKeyEventDataAndroid) {
      RawKeyDownEvent rawKeyDownEvent = event;
      RawKeyEventDataAndroid rawKeyEventDataAndroid =
      rawKeyDownEvent.data as RawKeyEventDataAndroid;
      if(rawKeyEventDataAndroid.keyCode == KEY_CENTER){
        setState(() {
          widget.controller.value.isPlaying
              ? widget.controller.pause()
              : widget.controller.play();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // _timeOut();
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        VideoProgressIndicator(widget.controller, allowScrubbing: true),
        Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                child: RawKeyboardListener(
                  focusNode: fastRewind,
                  onKey: _setKeyEvent,
                  child: ElevatedButton(
                    autofocus: false,
                      style: ButtonStyle(backgroundColor:MaterialStateProperty.all(fastRewind.hasFocus ? Colors.red : Colors.blue) ),
                      onPressed: () {},
                      child: Icon(
                        Icons.fast_rewind,
                        color: Colors.white,
                      )),
                ),
              ),
              SizedBox(
                width: 12,
              ),
              Container(
                child: RawKeyboardListener(
                  focusNode: playPauseFocusNode,
                  onKey: _setKeyEvent,
                  child: ElevatedButton(
                    autofocus: false,
                    style: ButtonStyle(backgroundColor:MaterialStateProperty.all(playPauseFocusNode.hasFocus ? Colors.red : Colors.blue) ),
                      onPressed: () {
                        setState(() {
                          widget.controller.value.isPlaying
                              ? widget.controller.pause()
                              : widget.controller.play();
                        });
                      },
                      child: Icon(
                        widget.controller.value.isPlaying
                            ? Icons.pause
                            : Icons.play_arrow,
                        color: Colors.white,
                      )),
                ),
              ),
              SizedBox(
                width: 12,
              ),
              Container(
                child: RawKeyboardListener(
                  focusNode: fastForward,
                  onKey: _setKeyEvent,
                  child: ElevatedButton(
                      autofocus: false,
                      style: ButtonStyle(backgroundColor:MaterialStateProperty.all(fastForward.hasFocus ? Colors.red : Colors.blue) ),
                      onPressed: () {},
                      child: Icon(
                        Icons.fast_forward,
                        color: Colors.white,
                      )),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}
